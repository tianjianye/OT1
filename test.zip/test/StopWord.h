#include <iostream>
#include <string>
#include <stdio.h>
#include "Stemmer.h"
#include <vector>
using namespace std;
class StopWord{

protected:

public:
	vector<string> removeStopWords(Stemmer* s,int size);
	void display(vector<string> myContainer);
};
