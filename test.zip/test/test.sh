make clean > /dev/null
make all > /dev/null
./Stemmer
