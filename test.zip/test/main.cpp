#include <iostream>
#include <string>
#include <cstring>
#include <stdio.h>
#include <ctype.h>
#include <algorithm>
#include "StopWord.h"
#include <fstream>
#include <iomanip>


using namespace std;
void stemming(vector<string> result,Stemmer s[]){
	int i=0;
	int size=result.size();
	cout<<size<<endl;
	while(i<size && result.at(i).compare("")!=0){	
		s[i].add(result.at(i),result.at(i).size());
		s[i].stem();
		i++;
	}
	for(int a=0;a<i;a++){
		cout<<"Result: "<<a<<":"<<s[a].toString()<<endl;
	}
}

int main(){
	Stemmer s[500];
	string test = "heavy rains caused blood to flow from a border burial site into a tributary of the imjin river african swine fever is highly contagious and incurable with a near zero survival rate for infected pigs but it is not dangerous to humans local authorities dismissed concerns that the blood could cause the spread of african swine fever to other at risk animals saying the pigs had already been disinfected before being slaughtered";
    vector<string> result;
    istringstream iss(test);
    for(string s; iss >> s; )result.push_back(s);
	stemming(result,s);
	StopWord sw;
	vector<string> result1=sw.removeStopWords(s,sizeof(s)/sizeof(s[0]));
	sw.display(result1);
	return 0;
}
