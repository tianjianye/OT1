#include <iostream>
#include <string>
#include <cstring>
#include <stdio.h>
using namespace std;
class Stemmer{

protected:

public:
	string s="";
	int i=0;
	int i_end=0;
	int j;
	int k;
	string toString();
	void add(string w,int wLen);
	int getResultLength();
	string getResultBuffer();
	bool cons(int i);
	int m();
	bool vowelinstem();
	bool doublec(int j);
	bool cvc(int i);
	bool ends(string racine);
	void setto(string newString);
	void r(string newString);
	void step1();
	void step2();
	void step3();
	void step4();
	void step5();
	void step6();
	void stem();
};
