#include <iostream>
#include <vector>
#include <deque>
#include <algorithm>
#include <fstream>
#include <string>
#include "StopWord.h"
using namespace std;
template <class Container, class RemoveTargetContainer>
typename Container::iterator remove_for(Container& container, const RemoveTargetContainer& targets)
{
    auto container_first = std::begin(container);
    auto container_last = std::end(container);

    std::for_each(std::begin(targets), std::end(targets),
        [&](typename RemoveTargetContainer::const_reference target)
        {
            container_last = std::remove(container_first, container_last, target);
        }
    );

    return container_last;
}

vector<string> StopWord::removeStopWords(Stemmer s[],int size){
	ifstream file( "listStopWords.txt" ) ; 
	deque <string> removalTargets;
	vector <string> myContainer;
	int i=0;
	while(i<size && s[i].toString().compare("")!=0){
		myContainer.push_back(s[i].toString());
		i++;
	}
	string line;
	while(getline(file,line)){
		removalTargets.push_back(line);
	}
	myContainer.erase(remove_for(myContainer, removalTargets), end(myContainer));
	return myContainer;
}
void StopWord::display(vector<string> myContainer){
	for (vector<int>::size_type i = 0; i < myContainer.size(); i++) {
		cout <<i<<":"<<myContainer.at(i) << endl;
	}
}
